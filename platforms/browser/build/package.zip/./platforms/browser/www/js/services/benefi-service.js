angular.module('app.benefiService', ['ngResource'])

.factory("benefiResource", function($http,$rootScope) {

	var service = {};

	service.get = function(model) {
		var id = '';

		if( typeof model.moedaDestino != "undefined" && model.moedaDestino != null){
			id = model.moedaDestino.id;
		}
		var config = {
			headers : {
				'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
			}
		}
		return $http(
			{
				method: 'GET',
				url: $rootScope.baseURL+'/RestFull/beneficiarios/'+model.HASH+'/'+id,
				config:config
			});


	};


	
	return service;
});