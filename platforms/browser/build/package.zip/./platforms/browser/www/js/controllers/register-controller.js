angular.module('app.register-controller', [])

.controller('RegisterController', function($scope) {
	$scope.usuario = {};
	
});