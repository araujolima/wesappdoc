angular.module('app.profile-controller', ['app.profileService'])

.controller('ProfileController', function($scope,profileResource,$ionicLoading,$rootScope,$localStorage) {
	$scope.profile = {};
	$ionicLoading.show({
		template: 'Loading...'
	}).then(function(){
	});
	var key = 'user';
	$rootScope.user = $localStorage.getObject(key);
	profileResource.get($rootScope.user)
	.success(function(data, status, headers, config) {
		data.MOBILE = Number(data.MOBILE);
		data.DATEOFBIRTH =  new Date(data.DATEOFBIRTH);
		$scope.profile = data;
		$ionicLoading.hide();
	})
	.error(function(data, status, headers, config) {
		$scope.profile = {};
		$ionicLoading.hide();
	});

	$scope.submit = function(){
		if(this.formprofile.$valid){
			$ionicLoading.show({
				template: 'Loading...'
			}).then(function(){
			});
			profileResource.post($scope.profile)
			.success(function(data, status, headers, config) {
				$scope.profile = data;
				$ionicLoading.hide();
			})
			.error(function(data, status, headers, config) {
				$ionicLoading.hide();
			});
		}
	}

});