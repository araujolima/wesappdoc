angular.module('app.benefi-persist-controller', [])

.controller('BenefiPersistController', function($scope) {

	

});