angular.module('app.documents-controller', [])

.controller('DocumentsController', function($scope) {

	

});