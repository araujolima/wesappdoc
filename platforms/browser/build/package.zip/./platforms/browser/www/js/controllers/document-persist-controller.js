angular.module('app.document-persist-controller', ['app.tipoDocService','app.profileDocumentsService'])

.controller('DocumentPersistController', function($scope,tipoDocResource,profileDocumentsResource,$ionicLoading) {
	$scope.documentTypes = [];
	$scope.document = {
		docType : {},
		number: null,
		valid: null
	}

	$ionicLoading.show({
		template: 'Loading...'
	}).then(function(){
	});
	tipoDocResource.get()
	.success(function(data, status, headers, config) {
		$scope.documentTypes = data;
		$ionicLoading.hide();
	})
	.error(function(data, status, headers, config) {
		$ionicLoading.hide();
	});


	$scope.saveDoc = function(){
		console.log($scope.document);
		$ionicLoading.show({
			template: 'Loading...'
		}).then(function(){
		});
		profileDocumentsResource.post($scope.document)
		.success(function(data, status, headers, config) {
			$scope.documentTypes = data;
			$ionicLoading.hide();
		})
		.error(function(data, status, headers, config) {
			$ionicLoading.hide();
		});
	}


	$scope.getCamera = function(ieFront){
		if(navigator.camera != null 
			&& typeof navigator.camera != "undefined" ){
			navigator.camera.getPicture(onSuccess, onFail, { quality: 100,
				destinationType: Camera.DestinationType.FILE_URI });
		
		function onSuccess(imageURI) {
			if(ieFront){
				$scope.document.frontImg = imageURI;
			}else{
				$scope.document.backImg = imageURI;
			}
		}
		function onFail(message) {
		}
	}
};


});