angular.module('app.benefi-controller' ,['app.benefiService'])

.controller('BenefiController', function($scope,benefiResource,$ionicLoading,$rootScope,$localStorage,$stateParams) {

	$scope.beneficioarios = [];
	$ionicLoading.show({
		template: 'Loading...'
	}).then(function(){
	});
	var key = 'user';
	$rootScope.user = $localStorage.getObject(key);
	var options = $rootScope.user;
	if( typeof $stateParams.moedaDestino != "undefined" && $stateParams.moedaDestino != null){
		options.moedaDestino = $stateParams.moedaDestino;
		$scope.ieSend = true;
	}else{
		$scope.ieSend = false;
	}
	benefiResource.get(options)
	.success(function(data, status, headers, config) {
		$scope.beneficioarios = data;
		$ionicLoading.hide();
	})
	.error(function(data, status, headers, config) {
		$scope.beneficioarios = [];
		$ionicLoading.hide();
	});
});