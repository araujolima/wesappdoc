angular.module('app.invite-controller', [])

.controller('InviteController', function($scope) {

	

});