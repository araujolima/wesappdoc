// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.services' is found in services.js
// 'starter.controllers' is found in controllers.js
angular.module('app', ['ionic','ngLocalStorage', 'app.controllers', 'app.services','app.home-controller','app.login-controller',
  'app.register-controller','app.invite-controller','app.transfers-controller','app.benefi-controller','app.documents-controller',
  'app.document-persist-controller','app.profile-controller','app.benefi-persist-controller','ui.utils.masks'])

.run(function($ionicPlatform, $rootScope,$ionicHistory,$state,$localStorage) {

  //$rootScope.baseURL = 'http://www.infohds.com.br';
  $rootScope.baseURL = 'http://51.255.43.175:80';
  $rootScope.user = {};

  //$rootScope.baseURL = 'http://192.168.25.18:8080';
  //$rootScope.baseURL = 'http://lucasgreis92.hopto.org:8080';
  
  $ionicPlatform.ready(function() {

    // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
    // for form inputs)
    if (window.cordova && window.cordova.plugins && window.cordova.plugins.Keyboard) {
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
      // org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
  $rootScope.goRegister = function(){
    $state.go('register');
  }
  $rootScope.goLogin = function(){
    $state.go('login');
  }
  $rootScope.myGoBack = function() {
    $ionicHistory.goBack();
  };
  $rootScope.goTabHome = function() {
    $state.go('tab.home');
  };

  $rootScope.logout = function(){
    var key = 'user';
    $localStorage.putObject(key,{});
    $rootScope.user = {};
    $state.go('home');
  }
  $rootScope.goBenefiPesist = function(){
    $state.go('tab.benefi-persist');
  }
  $rootScope.goHomeBenefi = function(moedaDestino){
    $state.go('tab.home-benefi',{moedaDestino:moedaDestino});
  }

  $rootScope.goDocuments = function(){
    $state.go('tab.documents');
  }

  $rootScope.goDocumentPersist = function(){
    $state.go('tab.document-perist');
  }
  
})

.config(function($stateProvider, $urlRouterProvider,$ionicConfigProvider,$httpProvider) {
  $ionicConfigProvider.tabs.position('bottom');

  // ajustes para ws em php
  /*$httpProvider.defaults.headers.common = {};
  $httpProvider.defaults.headers.post = {};
  $httpProvider.defaults.headers.put = {};
  $httpProvider.defaults.headers.patch = {};**/


  
  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider

  .state('home',{
    url:'/home/{params:json}',
    params: {params: null},
    cache:false,
    templateUrl:'templates/home.html',
    controller:'HomeController' 
  })


  .state('login',{
    url:'/login',
    templateUrl:'templates/login.html',
    controller:'LoginController' 

  })

  .state('register',{
    url:'/register',
    cache:false,
    templateUrl:'templates/register.html',
    controller:'RegisterController' 

  })
  // setup an abstract state for the tabs directive
  .state('tab', {
    url: '/tab',
    abstract: true,
    templateUrl: 'templates/tabs.html'
  })

  .state('tab.home', {
    url: '/home/{params:json}',
    cache:false,
    params: {params: {}},
    views: {
      'tab-home': {
        templateUrl: 'templates/tab-home.html',
        controller: 'HomeController'
      }
    }
  })

  .state('tab.home-benefi', {
    url: '/home-benefi/{moedaDestino:json}',
    params:{moedaDestino:null},
    cache:false,
    views: {
      'tab-home': {
        templateUrl: 'templates/benefi.html',
        controller: 'BenefiController'
      }
    }
  })
  .state('tab.invite', {
    url: '/invite',
    cache:false,
    views: {
      'tab-invite': {
        templateUrl: 'templates/invite.html',
        controller: 'InviteController'
      }
    }
  })
  .state('tab.transfers', {
    url: '/transfers',
    cache:false,
    views: {
      'tab-transfers': {
        templateUrl: 'templates/transfers.html',
        controller: 'TransfersController'
      }
    }
  })
  .state('tab.benefi', {
    url: '/benefi',
    cache:false,
    views: {
      'tab-benefi': {
        templateUrl: 'templates/benefi.html',
        controller: 'BenefiController'
      }
    }
  })
  .state('tab.benefi-persist', {
    url: '/benefi-persist',
    cache:false,
    views: {
      'tab-benefi': {
        templateUrl: 'templates/benefi-persist.html',
        controller: 'BenefiPersistController'
      }
    }
  })

  .state('tab.profile', {
    url: '/profile',
    cache:false,
    views: {
      'tab-profile': {
        templateUrl: 'templates/profile.html',
        controller: 'ProfileController'
      }
    }
  })

  .state('tab.documents',{
    url:'/documents',
    cache:false,
    views:{
      'tab-profile':{
        templateUrl:'templates/documents.html',
        controller:'DocumentsController'     
      }
    }
  })

.state('tab.document-perist',{
    url:'/document-persist',
    cache:false,
    views:{
      'tab-profile':{
        templateUrl:'templates/document-persist.html',
        controller:'DocumentPersistController'     
      }
    }
  })

  // Each tab has its own nav history stack:

  /*.state('tab.dash', {
    url: '/dash',
    views: {
      'tab-dash': {
        templateUrl: 'templates/tab-dash.html',
        controller: 'DashCtrl'
      }
    }
  }) **/


  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/home/');
    //$urlRouterProvider.otherwise('/home')

  });
